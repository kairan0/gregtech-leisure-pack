---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Oversize Interface
    icon: expatternprovider:oversize_interface
categories:
- extended devices
item_ids:
- expatternprovider:oversize_interface
- expatternprovider:oversize_interface_part
---

# ME Oversize Interface

<Row gap="20">
<BlockImage id="expatternprovider:oversize_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_oversize_interface.snbt"></ImportStructure>
</GameScene>
</Row>

ME Oversize Interface has the same number of slots as <ItemLink id="expatternprovider:ex_interface" />, but it can hold x16 time (configurable) more
items per slot. It means it can hold 1024 (64x16) items per slot.

Certain stuff from other mods can have specific multiplier by config.
